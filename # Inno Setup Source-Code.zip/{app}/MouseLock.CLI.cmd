@Echo Off

Title %~nx0
Mode CON Cols=80 Lines=52

CMD /K "%~n0.exe" ^| MORE